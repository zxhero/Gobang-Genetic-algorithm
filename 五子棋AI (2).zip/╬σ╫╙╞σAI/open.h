 int boardsize;
 typedef struct move{
	int x;
	int y;
	int flag;
}move;
typedef struct generation {
	short int gene[200];
	double fit;
	double part;
	double sum_part;
	double gene_value[10];
}generation;
move my;
move* recordmove[400];
int board[400];
int moveNum = 0;
int gene_long;
int loc[400];
int cmp(const void* a, const void* b) {
	if (fabs((*(generation*)a).fit) < fabs((*(generation*)b).fit)) return 1;
	else if (fabs((*(generation*)a).fit) > fabs((*(generation*)a).fit)) return -1;
	else if((*(generation*)a).fit<0&&(*(generation*)b).fit<0){
		if((*(generation*)a).gene_value[1]<(*(generation*)b).gene_value[1]){
			return 1;
		}
		else if((*(generation*)a).gene_value[1]>(*(generation*)b).gene_value[1]){
			return -1;
		}
	}
	else if((*(generation*)a).fit>0&&(*(generation*)b).fit>0){
		if((*(generation*)a).gene_value[0]<(*(generation*)b).gene_value[0]){
			return 1;
		}
		else if((*(generation*)a).gene_value[0]>(*(generation*)b).gene_value[0]){
			return -1;
		}
	}
	else if((*(generation*)a).fit>0&&(*(generation*)b).fit<0){
		if((*(generation*)a).gene_value[0]<(*(generation*)b).gene_value[1]){
			return 1;
		}
		else if((*(generation*)a).gene_value[0]>(*(generation*)b).gene_value[1]){
			return -1;
		}
	}
	else if((*(generation*)a).fit<0&&(*(generation*)b).fit>0){
		if((*(generation*)a).gene_value[1]<(*(generation*)b).gene_value[0]){
			return 1;
		}
		else if((*(generation*)a).gene_value[1]>(*(generation*)b).gene_value[0]){
			return -1;
		}
	}
	else return 0;
}
int cmp2(const void* a, const void*b) {
	return *(int*)a - *(int*)b;
}

 int open(){
 	if(moveNum==1){
 		if(recordmove[0]->x<=15&&recordmove[0]->x>=5&&recordmove[0]->y<=15&&recordmove[0]->y>=5){
 			my.x=recordmove[0]->x;
 		    my.y=recordmove[0]->y-1;
 		    my.flag=1;
 		    return 1;
		}
 		else {
 			my.x=9;
 			my.y=9;
 			my.flag=1;
 			return 1;
		} }
	else if(moveNum==3){
	 	if(board[189]!=1&&recordmove[2]->x==recordmove[0]->x-1&&recordmove[2]->y==recordmove[0]->y){
	 		my.x=recordmove[0]->x-1;
	 		my.y=recordmove[0]->y+1;
	 		my.flag=1;
	 		return 1;
		 }
		 else if(board[189]!=1&&recordmove[2]->x==recordmove[0]->x+1&&recordmove[2]->y==recordmove[0]->y){
		 	my.x=recordmove[0]->x+1;
	 		my.y=recordmove[0]->y+1;
	 		my.flag=1;
	 		return 1;
		 }
		 else if(board[189]!=1&&recordmove[2]->x==recordmove[0]->x&&recordmove[2]->y==recordmove[0]->y+1){
		 	my.x=recordmove[0]->x+1;
	 		my.y=recordmove[0]->y+1;
	 		my.flag=1;
	 		return 1;
		 }
		 else if(board[189]!=1&&recordmove[2]->x==recordmove[0]->x-1&&recordmove[2]->y==recordmove[0]->y+1||recordmove[2]->x==recordmove[0]->x-1&&recordmove[2]->y==recordmove[0]->y-1){
		 	my.x=recordmove[0]->x-2;
	 		my.y=recordmove[0]->y;
	 		my.flag=1;
	 		return 1;
		 }
		 else if(recordmove[2]->x==recordmove[0]->x+1&&recordmove[2]->y==recordmove[0]->y-1||recordmove[2]->x==recordmove[0]->x+1&&recordmove[2]->y==recordmove[0]->y+1){
		 	my.x=recordmove[0]->x+2;
	 		my.y=recordmove[0]->y;
	 		my.flag=1;
	 		return 1;
		 }
		 else{
		 	my.x=recordmove[1]->x+1;
		 	my.y=recordmove[1]->y;
		 	my.flag=1;
			return 1;
		 }
	 }
 	else if(moveNum==2){
 		if(board[189]==1&&(board[169]==2||board[190]==2)){   //���¿��� 
 			my.x=10;
 			my.y=8;
 			my.flag=1;
 			return 1; 
		 }
		else if(board[189]==1&&(board[209]==2||board[188]==2)){
			my.x=8;
			my.y=10;
			my.flag=1;
			return 1;
		}
		if(board[189]==1&&(board[170]==2||board[208]==2)){    //���¿��� 
			my.x=10;
			my.y=10;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&(board[168]==2||board[210]==2)){
			my.x=10;
			my.y=8;
			my.flag=1;
			return 1;
		}
		else return 0;
	 }
	else if(moveNum==4){
		if(board[189]==1&&board[169]==2&&board[170]==1&&(board[151]==2||board[208]==2)){
			my.x=10;
			my.y=10;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[190]==2&&board[170]==1&&(board[151]==2||board[208]==2)){
			my.x=8;
			my.y=8;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&(board[169]==2||board[190]==2)&&board[170]==1&&board[151]==0&&board[208]==0&&board[227]==0){
			my.x=8;
			my.y=10;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&(board[169]==2||board[190]==2)&&board[170]==1&&board[151]==0&&board[208]==0&&board[132]==0){
			my.x=11;
			my.y=7;
			my.flag=1;
			return 1;
		}
		//
		else if(board[189]==1&&board[209]==2&&board[208]==1&&(board[170]==0||board[227]==0)){
			my.x=8;
			my.y=8;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[188]==2&&board[208]==1&&(board[170]==2||board[227]==2)){
			my.x=10;
			my.y=10;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&(board[188]==2||board[209]==2)&&board[208]==1&&board[170]==0&&board[227]==0&&board[170]==0){
			my.x=10;
			my.y=9;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&(board[188]==2||board[209]==2)&&board[208]==1&&board[170]==0&&board[227]==0&&board[246]==0){
			my.x=7;
			my.y=11;
			my.flag=1;
			return 1;
		}
		//
		//
		if(board[189]==1&&board[170]==2&&board[168]==2){
			my.x=11;
			my.y=8;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[170]==2&&board[231]==2){
			my.x=11;
			my.y=9;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[208]==2&&board[168]==2){
			my.x=8;
			my.y=11;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[208]==2&&board[231]==2){
			my.x=9;
			my.y=11;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&(board[170]==2||board[208]==2)&&board[168]==0&&board[231]==0){
			my.x=8;
			my.y=8;
			my.flag=1;
			return 1;
		}
		//
		else if(board[189]==1&&board[168]==2&&board[208]==2){
			my.x=8;
			my.y=7;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[210]==2&&board[208]==2){
			my.x=11;
			my.y=10;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&(board[168]==2||board[210]==2)&&board[208]==0){
			my.x=8;
			my.y=10;
			my.flag=1;
			return 1;
		}
		else return 0;
	}
	else if(moveNum==6){
		if(board[189]==1&&board[169]==2&&board[170]==1&&board[208]==1&&board[191]==0){
			my.x=11;
			my.y=9;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[169]==2&&board[170]==1&&board[208]==1&&board[210]==0){
			my.x=10;
			my.y=10;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[190]==2&&board[170]==1&&board[208]==1&&board[149]==0){
			my.x=9;
			my.y=7;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[190]==2&&board[170]==1&&board[208]==1&&board[168]==0){
			my.x=8;
			my.y=8;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[169]==2&&board[170]==1&&(board[150]==2||board[190]==2||board[230]==2)&&board[210]==1){
			my.x=8;
			my.y=8;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[169]==2&&board[170]==1&&board[190]==0&&board[210]==1){
			my.x=10;
			my.y=9;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[190]==2&&board[170]==1&&board[168]==1&&(board[167]==2||board[169]==2||board[171]==2)){
			my.x=10;
			my.y=10;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[190]==2&&board[170]==1&&board[168]==1&&board[169]==0){
			my.x=9;
			my.y=8;
			my.flag=1;
			return 1;
		}
		//
		else if(board[189]==1&&board[209]==2&&board[208]==1&&board[170]==1&&board[187]==0){
			my.x=7;
			my.y=9;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[209]==2&&board[208]==1&&board[170]==1&&board[168]==0){
			my.x=8;
			my.y=8;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[188]==2&&board[170]==1&&board[208]==1&&board[210]==0){
			my.x=10;
			my.y=10;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[188]==2&&board[170]==1&&board[208]==1&&board[191]==0){
			my.x=11;
			my.y=9;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[209]==2&&board[208]==1&&(board[228]==2||board[188]==2||board[148]==2)&&board[168]==1){
			my.x=10;
			my.y=10;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[209]==2&&board[208]==1&&board[188]==0&&board[168]==1){
			my.x=8;
			my.y=9;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[188]==2&&board[208]==1&&board[210]==1&&(board[207]==2||board[209]==2||board[211]==2)){
			my.x=10;
			my.y=8;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[188]==2&&board[208]==1&&board[210]==1&&board[209]==0){
			my.x=9;
			my.y=10;
			my.flag=1;
			return 1;
		}
		//
		//
		if(board[189]==1&&board[170]==2&&board[168]==2&&board[191]==2){
			my.x=9;
			my.y=10;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[170]==2&&board[168]==2&&board[191]==0){
			my.x=11;
			my.y=9;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[208]==2&&board[168]==2&&board[229]==2){
			my.x=10;
			my.y=9;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[208]==2&&board[168]==2&&board[229]==0){
			my.x=9;
			my.y=11;
			my.flag=1;
			return 1;
		}
		//
		else if(board[189]==1&&board[168]==2&&board[208]==2&&board[149]==2){
			my.x=10;
			my.y=9;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[168]==2&&board[208]==2&&board[149]==0){
			my.x=9;
			my.y=7;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[210]==2&&board[208]==2&&board[191]==2){
			my.x=9;
			my.y=8;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[210]==2&&board[208]==2&&board[191]==0){
			my.x=11;
			my.y=9;
			my.flag=1;
			return 1;
		}
		else return 0;
	}
	else if(moveNum==8){
		if(board[189]==1&&board[169]==2&&board[170]==1&&board[208]==1&&board[227]==2&&board[191]==1&&board[149]==0){
			my.x=9;
			my.y=7;
			my.flag=1;
			return 1;
		}
		else if(board[189]==1&&board[169]==2&&board[170]==1&&board[208]==1&&board[227]==2&&board[191]==1&&board[149]==2&&board[190]==0){
			my.x=10;
			my.y=9;
			my.flag=1;
			return 1;
		}
		else return 0;
	}
	else return 0;
 }
