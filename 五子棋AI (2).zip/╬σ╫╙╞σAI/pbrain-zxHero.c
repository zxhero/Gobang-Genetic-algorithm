#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#include"open.h"
#define BEGIN 1
#define START 0
#define TURN 2
#define BOARD 3
#define END 4
#define RESTART 5
#define PRINT 6
#define INFO 7
#define group_scale 800    //��P���������п������м�ֵ�ĵ� 

int checkPara(char* x1);
void Answer(int k);
move MyAI();
double rrrandom(double x);
void mutation(generation* group);
void pick(generation* group, generation* group_new);
void crosover(generation* group);
void generate(generation* group);
double evalue(generation* way);
void output(generation* group);
int evaluesingle(int x, int y, int id);
int judge();
int initial(int i);

int main(){
	int i;
	for(i=0;i<400;i++){
		recordmove[i] = 0;
		board[i] = 0;
	}
	char para[20];
	int k;
	srand((unsigned int)time(NULL));
	while(1){
		for(i=0;i<20;i++){
		para[i] = 0;
	}
	scanf("%s",para);
	k = checkPara(para);
	if(k==END) break;
	else Answer(k);
}
	return 0;
} 

int checkPara(char* x1){
	int i;
	char parameter[][8]={"START","BEGIN","TURN","BOARD","END","RESTART","PRINT","INFO"};
	if((i = strcmp(x1,parameter[2]))==0){
		char s[6];
		char *x,*y;
		int number;
		recordmove[moveNum] = (move*)calloc(1,sizeof(move));
		scanf("%s",s);
		x = strtok(s,",");
		y = strtok(NULL,"\n");
		recordmove[moveNum]->x = atoi(x);
		recordmove[moveNum]->flag = 2;
		recordmove[moveNum]->y = atoi(y);
		number = recordmove[moveNum]->x + recordmove[moveNum]->y*20;
		board[number] = 2;
		moveNum++;
		return TURN;
	}
	else if((i = strcmp(x1,parameter[0]))==0){
		scanf("%d",&boardsize);
		return START;
	}
	else if((i = strcmp(x1,parameter[5]))==0){
		return RESTART;
	}
	else if((i = strcmp(x1,parameter[6]))==0){
		return PRINT;
	}
	else if((i = strcmp(x1,parameter[7]))==0){
		char s[100];
		char t[100];
		scanf("%s%s",s,t);
		return INFO;
	}
	else if((i = strcmp(x1,parameter[4]))==0){
		return END;
	}
	else if((i = strcmp(x1,parameter[3]))==0){
		return BOARD;
	}
	else if((i = strcmp(x1,parameter[1]))==0){
		return BEGIN;
	}
}

void Answer(int k){
	int j;
	switch(k){
		case START:
			printf("OK\n");
			fflush(stdout);
			break;
		case BEGIN:
			board[189]=1;
			printf("9,9\n");
			recordmove[moveNum] = (move*)calloc(1,sizeof(move));
			recordmove[moveNum]->x = 9;
		    recordmove[moveNum]->flag = 1;
		    recordmove[moveNum]->y = 9;
		    moveNum++;
			fflush(stdout);
			break;
		case TURN:
			if(judge()); 
			else if(open());
			else{
				my=MyAI();
			}
			board[my.x+my.y*20]=1;
			recordmove[moveNum] = (move*)calloc(1,sizeof(move));
			recordmove[moveNum]->x = my.x;
		    recordmove[moveNum]->flag = 1;
		    recordmove[moveNum]->y = my.y;
		    moveNum++;
			printf("%d,%d\n",my.x,my.y);
			fflush(stdout);
			break;
		case BOARD:
			my = MyAI();
			printf("%d,%d\n",my.x,my.y);
			fflush(stdout);
			break;
		case RESTART:
			for(j=0;j<400;j++){
				board[j]=0;
				recordmove[j]=0;
			}
			moveNum=0;
			printf("OK\n");
			fflush(stdout);;
			break;
		case PRINT:
			for(j=0;j<moveNum;j++){
				printf("%d %d %d\n",recordmove[j]->x,recordmove[j]->y,recordmove[j]->flag);
			}
			break;
		default:
			break;
	}
}

move MyAI() {
	int j, k,m,n,i;
	move* now = (move*)calloc(1, sizeof(move));
	generation group[group_scale];
	generation group_new[group_scale];
	generate(group);
	for (j = 0; j<1700; j++) {
		pick(group, group_new);
		crosover(group_new);
		mutation(group_new);
		qsort(group_new, group_scale, sizeof(generation), cmp);
		qsort(group, group_scale, sizeof(generation), cmp);
		for (k = 2; k<group_scale; k++) {
			group[k] = group_new[k - 2];
		}
	}
	qsort(group, group_scale, sizeof(generation), cmp);
		if (group[0].fit>0) {
			now->x = group[0].gene[0];
			now->y = group[0].gene[1];
		}
		else {
			now->x = group[0].gene[2];
			now->y = group[0].gene[3];
		}
	now->flag = 1;
	return *now;
}

double rrrandom(double x) {
	double y;
	y = (x*rand() / (RAND_MAX + 1.0));
	return y;
}

void generate(generation* group) {
	int i,k,j,m,n;
	gene_long=0;
	int a[400];
	for (i = 0; i<400; i++) {                      //��ѡ�����ӵ�λ��
	    a[i]=0; 
		if (board[i] == 0) {
			m=i%20;
			n=i/20;
			if(initial(i)&&evaluesingle(m,n,1)+evaluesingle(m,n,2)>=160){
				loc[gene_long/2]=i;
				a[gene_long/2]=1;
				gene_long+=2;
			}}}
	for (i = 0; i<group_scale; i++) {                            //���ҵ�����������У��γ�һ������ 
		for (j = 0; j<gene_long; j++) {
			do{    k = rrrandom((double)gene_long/2);
			}while(!a[k]);
			group[i].gene[j++] = loc[k] % 20;
			group[i].gene[j] = loc[k] / 20;
			a[k]=0;
		}
		group[i].fit = evalue(&group[i]);
		for (j = 0; j<gene_long/2; j++) {
			a[j] = 1;
		}}}

void pick(generation* group, generation* group_new) {
	int sum = 0, i, j = 0;
	double pos, spart = 0.0;
	for (i = 0; i<group_scale; i++) {	sum += fabs(group[i].fit);	}
	for (i = 0; i<group_scale; i++) {
		group[i].part = fabs(group[i].fit) / sum;
		spart += group[i].part;
		group[i].sum_part = spart;
	}
	while (j<group_scale) {
		pos = rrrandom(1.0);
		for (i = 0; i<group_scale; i++) {
			if ((pos>group[i].sum_part) && (pos<group[i + 1].sum_part)) {
				group_new[j++] = group[i];
				break;
		}}}}

void crosover(generation* group) {
	int a[group_scale];
	int i, j, L, DNA, M, R, k, n, v, w;
	int gene1[gene_long];
	int gene2[gene_long];
	for (i = 0; i<group_scale; i++) {	a[i] = 0;	}
	for (i = 0; i<group_scale; i++) {
		if (a[i] == 0) {
			a[i] = 1;
			for (; ; )
			{
				j = i + (int)rrrandom((double)group_scale - i);          //�ҵ������i��Է��ܵĸ���j
				if (a[j] == 0) break;
			}
			if (rrrandom(1.0)>0.6) {
				R = (int)rrrandom(gene_long / 2.0);
				M = (int)rrrandom(gene_long / 2.0);
				L = (int)rrrandom(gene_long / 2.0);
				for (k = 0, n = 0; k<gene_long/2 || n<gene_long/2;) {               //��λ����л�λ
					v = group[i].gene[2 * k] + group[i].gene[2 * k + 1] * 20;
					w = group[j].gene[2 * n] + group[j].gene[2 * n + 1] * 20;
					if (v == loc[R] || v == loc[M] || v == loc[L]) {
						gene1[2 * k] = group[i].gene[2 * k];
						gene1[2 * k + 1] = group[i].gene[2 * k + 1];
						k++;
					}
					else if (w == loc[R] || w == loc[M] || w == loc[L]) {
						gene2[2 * n] = group[j].gene[2 * n];
						gene2[2 * n + 1] = group[j].gene[2 * n + 1];
						n++;
					}
					else {
						gene1[2 * k] = group[j].gene[2 * n];
						gene2[2 * n] = group[i].gene[2 * k];
						gene1[2 * k + 1] = group[j].gene[2 * n + 1];
						gene2[2 * n + 1] = group[i].gene[2 * k + 1];
						k++;
						n++;
					}
				}
				for (k = 0; k < gene_long >>1; k++) {
					group[i].gene[2*k] = gene1[2 * k];
					group[i].gene[2 * k + 1] = gene1[2 * k + 1];
					group[j].gene[2 * k] = gene2[2 * k];
					group[j].gene[2 * k + 1] = gene2[2 * k + 1];
				}
				group[i].fit = evalue(&group[i]);
				group[j].fit = evalue(&group[j]);
			}
			a[j] = 1;
		}}}

void mutation(generation* group) {           //���ո���0.002����������λ�ý��л���
	int m, i, k, h;
	for (i = 0; i<group_scale; i++) {
		if (rrrandom(1.0) < 0.1) {
			k = rrrandom(gene_long/2.0);
			while ((m = rrrandom(gene_long/2.0)) == k);
			h = group[i].gene[2 * m];
			group[i].gene[2 * m] = group[i].gene[2 * k];
			group[i].gene[2 * k] = h;
			h = group[i].gene[2 * m + 1];
			group[i].gene[2 * m + 1] = group[i].gene[2 * k + 1];
			group[i].gene[2 * k + 1] = h;
			k = rrrandom(gene_long/2.0);
			while ((m = rrrandom(gene_long/2.0)) == k);
			h = group[i].gene[2 * m];
			group[i].gene[2 * m] = group[i].gene[2 * k];
			group[i].gene[2 * k] = h;
			h = group[i].gene[2 * m + 1];
			group[i].gene[2 * m + 1] = group[i].gene[2 * k + 1];
			group[i].gene[2 * k + 1] = h;
			k = rrrandom(gene_long/2.0 );
			while ((m = rrrandom(gene_long/2.0)) == k);
			h = group[i].gene[2 * m];
			group[i].gene[2 * m] = group[i].gene[2 * k];
			group[i].gene[2 * k] = h;
			h = group[i].gene[2 * m + 1];
			group[i].gene[2 * m + 1] = group[i].gene[2 * k + 1];
			group[i].gene[2 * k + 1] = h;
			group[i].fit = evalue(&group[i]);
		}}}

double evalue(generation* way) {
	int i, x, y, j, number, max = 0, n;
	double sum=0.0,Q,P,antivalue;
	double value2[gene_long / 2];
	for (i = 0; i<16; i = i+2) {
		x = way->gene[i];
		y = way->gene[i + 1];
		number = x + y * 20;
		n = i % 4 / 2 + 1; 
		Q =  evaluesingle(x, y, n);
		P =  evaluesingle(x, y, 3 - n);
		if(n==1){
			if(Q>3*P){	value2[i / 2] = Q;		}
			else if(P>2.5*Q){	value2[i / 2] = P;		}
			else{	value2[i / 2] = (P+Q)/2 ;		}
		}   //�������ӵ�����ֵ
		else{	
		    if(Q>3*P){	value2[i / 2] = Q;		}
			else if(P>2.5*Q){	value2[i / 2] = P;		}
			else{	value2[i / 2] = (P+Q)/2 ;		}
		}   //�������ӵ�����ֵ
		if(i>=2){
			antivalue=value2[i/2]/value2[i/2-1];
		    if(antivalue<6){
			    sum=1;
			    goto jump;
		    }
		}
		if(n==1){sum+=value2[i/2];		}
		else{		sum-=value2[i/2];		}
		board[number] = n;   //1Ϊ�������ӣ�2Ϊ�Է����� ,0Ϊ��λ�������� 
	}
	jump : for (j = 0; j<i; j =j+ 2) {
		x = way->gene[j];
		y = way->gene[j + 1];
		number = x + y * 20;
		board[number] = 0;
	}
	way->gene_value[0]=value2[0];
	way->gene_value[1]=value2[1];
	return sum; 
}

int evaluesingle(int x, int y, int id) {
	int i,j,sum;
	int number = x + y * 20;
	int lag[4] = {1,1,1,1};
	int state[4][9] ;
	int flagg[8]={1,1,1,1,1,1,1,1};
	int direction[4] = {1,1,1,1};
	int value[4] = {0,0,0,0};             //�������ĸ���λ������ֵ 
	for(j=0;j<4;j++){
		for(i=0;i<9;i++){
			if(i==4) state[j][i]=1;
			else state[j][i]=0;
		}
	}
	for (j = 0; j<4; j++) {
		if ((y - j - 1 >= 0) ) {
			if (board[number - 20 * (j + 1)] == id) {
				if(flagg[0]) direction[0]++;
				state[0][4-j-1]=1;
			}
			else if (board[number - 20 * (j + 1)] == 0) {
				state[0][4-j-1] = 0;
				flagg[0]=0;
			}
			else { state[0][4-j-1] = -1;
			    flagg[0]=0;
		    }
		}
		else {	state[0][4-j-1]=-1;	}
		if ((y + j + 1<20) ) {
			if (board[number + 20 * (j + 1)] == id) {
				if(flagg[1]) direction[0]++;
				state[0][4+j+1]=1;
			}
			else if (board[number + 20 * (j + 1)] == 0) { state[0][4+j+1] = 0; flagg[1]=0;}
			else { state[0][4+j+1] = -1; flagg[1]=0;}
		}
		else{	state[0][4+j+1]=-1	;}
		if ((x - j - 1) >= 0) {
				if (board[number - 1 - j] == id) {
					if(flagg[2]) direction[1]++;
					state[1][4-1-j]=1;
				}
				else if (board[number - 1 - j] == 0) { state[1][4-j-1] = 0; flagg[2]=0;}
				else { state[1][4-j-1] = -1; flagg[2]=0;}
			if ((y - j - 1 >= 0)) {
				if (board[number - 20 * (j + 1) - 1 - j] == id) {
					if(flagg[4]) direction[3]++;
					state[3][4-j-1]=1;
				}
				else if (board[number - 20 * (j + 1) - 1 - j] == 0) { state[3][4-j-1] = 0; flagg[4]=0;}
				else { state[3][4-j-1] = -1; flagg[4]=0;}
			}
			else{	state[3][4-j-1] = -1;		} 
			if ((y + j + 1<20) ) {
				if (board[number + 20 * (j + 1) - 1 - j] == id) {
					if(flagg[7]) direction[2]++;
					state[2][4+j+1]=1;
				}
				else if (board[number + 20 * (j + 1) - 1 - j] == 0) { state[2][4+j+1] = 0; flagg[7]=0;}
				else { state[2][4+j+1] = -1; flagg[7]=0;}
			}
			else{	state[2][4+j+1] = -1;		}
		}
		else{
			state[1][4-1-j]=-1;
			state[3][4-j-1]=-1;
			state[2][4+j+1]=-1;
		}
		if (x + 1 + j<20) {
				if (board[number + 1 + j] == id) {
					if(flagg[3]) direction[1]++;
					state[1][4+j+1]=1;
				}
				else if (board[number + 1 + j] == 0) { state[1][4+j+1] = 0; flagg[3]=0;}
				else { state[1][4+j+1] = -1; flagg[3]=0;}
			if ((y - 1 - j >= 0)) {
				if (board[number - 20 * (j + 1) + 1 + j] == id) {
					if(flagg[6]) direction[2]++;
					state[2][4-j-1]=1;
				}
				else if (board[number - 20 * (j + 1) + 1 + j] == 0) { state[2][4-j-1] = 0; flagg[6]=0;}
				else { state[2][4-j-1] = -1; flagg[6]=0;}
			}
			else{	state[2][4-j-1] = -1;		}
			if ((y + j + 1<20)) {
				if (board[number + 20 * (j + 1) + j + 1] == id) {
					if(flagg[5]) direction[3]++;
					state[3][4+j+1]=1;
				}
				else if (board[number + 20 * (j + 1) + j + 1] == 0) { state[3][4+j+1] = 0; flagg[5]=0;}
				else { state[3][4+j+1] = -1; flagg[5]=0;}
			}
			else{	state[3][4+j+1] = -1;		}
		}
		else{
			state[1][4+j+1]=-1;
			state[2][4-j-1]=-1;
			state[3][4+j+1]=-1;
		}
	}
	for (j = 0; j<4; j++) {
		switch (direction[j]) {
		case 7:
		case 8:
		case 6:
		case 5:
			for(i=0;i<5;i++){
				if((state[j][i]==1)&&(state[j][i+1]==1)&&(state[j][i+2]==1)&&(state[j][i+3]==1)&&(state[j][i+4]==1)){
			        return 50000;
				}
			}
			break;
		case 4:
			for(i=0;i<4&&lag[j];i++){
				if((state[j][i]==0)&&(state[j][i+1]==1)&&(state[j][i+2]==1)&&(state[j][i+3]==1)&&(state[j][i+4]==1)&&(state[j][i+5]==0)){
					value[j]= 4320;
					lag[j]=0;
				}}
			for(i=0;i<5&&lag[j];i++){
				if((state[j][i]==0)&&(state[j][i+1]==1)&&(state[j][i+2]==1)&&(state[j][i+3]==1)&&(state[j][i+4]==1)){
					value[j]= 720;
					lag[j]=0;
				}}
			for(i=0;i<5&&lag[j];i++){
				if((state[j][i]==1)&&(state[j][i+1]==1)&&(state[j][i+2]==1)&&(state[j][i+3]==1)&&(state[j][i+4]==0)){
					value[j]= 720;
					lag[j]=0;
				}}
			break;
		case 3:
			for(i=0;i<5&&lag[j];i++){
				if((state[j][i]==0)&&(state[j][i+1]==1)&&(state[j][i+2]==1)&&(state[j][i+3]==1)&&(state[j][i+4]==0)&&(state[j][i+5]==0)){
					value[j]= 720;
				}}
			for(i=0;i<4&&lag[j];i++){
				if((state[j][i]==0)&&(state[j][i+1]==0)&&(state[j][i+2]==1)&&(state[j][i+3]==1)&&(state[j][i+4]==1)&&(state[j][i+5]==0)){
					value[j]= 720;
					lag[j]=0;
				}}
			for(i=0;i<5&&lag[j];i++){
				if((state[j][i]==1)&&(state[j][i+1]==1)&&(state[j][i+2]==1)&&(state[j][i+3]==0)&&(state[j][i+4]==1)){
					value[j]= 720;
					lag[j]=0;
				}}
			for(i=0;i<5&&lag[j];i++){
				if((state[j][i]==1)&&(state[j][i+1]==0)&&(state[j][i+2]==1)&&(state[j][i+3]==1)&&(state[j][i+4]==1)){
					value[j]= 720;
					lag[j]=0;
				}}
			if(lag[j]&&(state[j][1]==2)&&(state[j][2]==1)&&(state[j][3]==1)&&(state[j][4]==1)&&(state[j][5]==0)&&(state[j][6]==0)){
				value[j]=60;
			}
			break;
		case 2:
			for(i=0;i<4&&lag[j];i++){
				if((state[j][i]==0)&&(state[j][i+1]==1)&&(state[j][i+2]==1)&&(state[j][i+3]==0)&&(state[j][i+4]==1)&&(state[j][i+5]==0)){
					value[j]= 720;
					lag[j]=0;
				}}
			for(i=0;i<4&&lag[j];i++){
				if((state[j][i]==0)&&(state[j][i+1]==1)&&(state[j][i+2]==0)&&(state[j][i+3]==1)&&(state[j][i+4]==1)&&(state[j][i+5]==0)){
					value[j]= 720;
					lag[j]=0;
				}}
			for(i=0;i<5&&lag[j];i++){
				if((state[j][i]==1)&&(state[j][i+1]==1)&&(state[j][i+2]==0)&&(state[j][i+3]==1)&&(state[j][i+4]==1)){
					value[j]= 720;
					lag[j]=0;
				}}
			for(i=0;i<4&&lag[j];i++){
				if((state[j][i]==0)&&(state[j][i+1]==0)&&(state[j][i+2]==1)&&(state[j][i+3]==1)&&(state[j][i+4]==0)&&(state[j][i+5]==0)){
					value[j]= 120;
					lag[j]=0;
				}}
			if(lag[j]&&(state[j][1]==2)&&(state[j][2]==1)&&(state[j][3]==0)&&(state[j][4]==1)&&(state[j][5]==1)&&(state[j][6]==0)&&(state[j][7]==0)){
				value[j]=60;
			}
			break;
		case 1:
			if((state[j][0]==0)&&(state[j][1]==1)&&(state[j][2]==1)&&(state[j][3]==0)&&(state[j][4]==1)&&(state[j][5]==0)){
				value[j]=720;
			}
			else if((state[j][3]==0)&&(state[j][4]==1)&&(state[j][5]==0)&&(state[j][6]==1)&&(state[j][7]==1)&&(state[j][8]==0)){
				value[j]=720;
			}
			else if((state[j][4]==1)&&(state[j][5]==0)&&(state[j][6]==1)&&(state[j][7]==1)&&(state[j][8]==1)){
				value[j]=720;
			}
			else if((state[j][0]==1)&&(state[j][1]==1)&&(state[j][2]==1)&&(state[j][3]==0)&&(state[j][4]==1)){
				value[j]=720;
			}
			else if((state[j][2]==0)&&(state[j][3]==0)&&(state[j][4]==1)&&(state[j][5]==0)&&(state[j][6]==1)&&(state[j][7]==0)){
				value[j]=120; 
			} 
			else if((state[j][0]==0)&&(state[j][1]==0)&&(state[j][2]==1)&&(state[j][3]==0)&&(state[j][4]==1)&&(state[j][5]==0)){
				value[j]=120;
			}
			else if((state[j][3]==0)&&(state[j][4]==1)&&(state[j][5]==0)&&(state[j][6]==1)&&(state[j][7]==0)&&(state[j][8]==0)){
				value[j]=120;
			}
			else if((state[j][1]==0)&&(state[j][2]==1)&&(state[j][3]==0)&&(state[j][4]==1)&&(state[j][5]==0)&&(state[j][6]==0)){
				value[j]=120;
			}
			else if((state[j][1]==0)&&(state[j][2]==0)&&(state[j][3]==0)&&(state[j][4]==1)&&(state[j][5]==0)&&(state[j][6]==0)){
				value[j]=20;
			}
			else if((state[j][2]==0)&&(state[j][3]==0)&&(state[j][4]==1)&&(state[j][5]==0)&&(state[j][6]==0)&&(state[j][7]==0)){
				value[j]=20;
			}
			break;
		default:
			value[j]=0;
			break;
		}}
	for(sum=0,i=0;i<4;i++){	sum+=value[i];	}
	if(sum>=360&&sum<840){	sum=800;	}
	if(sum>=840&&sum<1440){	sum=1400;	} 
	if(sum>=1440&&sum<1600){	sum=3000;	}
	if(sum>=1600&&sum<4000){	sum=4000;	}
	return sum;
}

int initial(int i){
	int j,x,y;
	x=i%20;
	y=i/20;
	for(j=1;j<3;j++){
		if((y-j)>=0){	if(board[i-j*20]!=0) return 1;		}
		if((y+j)<20){	if(board[i+j*20]!=0) return 1;		}
	}
	for(j=1;j<3;j++){
		if(y-j>=0&&x+j<20){	if(board[i-j*20+j]!=0) return 1;		}
		if(y+j<20&&x-j>=0){	if(board[i+j*20-j]!=0) return 1;		}
	}
	for(j=1;j<3;j++){
		if(y-j>=0&&x-j>=0){	if(board[i-j*20-j]!=0) return 1;		}
		if(y+j<20&&x+j<20){	if(board[i+j*20+j]!=0) return 1;		}
	}
	for(j=1;j<3;j++){
		if((x-j)>=0){		if(board[i-j]!=0) return 1;		}
		if((x+j)<20){		if(board[i+j]!=0) return 1;		}
	}
	return 0;
}

int judge(){
	int point[8];
	int j=0,i,m,n,max=0,L,V;
	    for (i = 0; i<400; i++) {                      //�����Ƿ��г������ 
		if (board[i] == 0) {
			m = i % 20;
			n = i / 20;
			if(evaluesingle(m, n, 1)==50000){
				my.x=m;
				my.y=n;
				my.flag=1;
				return 1;
			}}}
	for(i=0;i<400;i++){
		if(board[i]==0){
			m=i%20;
			n=i/20;
		if(evaluesingle(m,n,2)==50000){
		    my.x=m;
		    my.y=n;
			my.flag=1;
			return 1;
	}}}
	for (i = 0; i<400; i++) {                      //�����Ƿ��г���ĵ��� 
		if (board[i] == 0) {
			m = i % 20;
			n = i / 20;
			if(evaluesingle(m, n, 1)>=4320){
				my.x=m;
				my.y=n;
				my.flag=1;
				return 1;
			}}}
	for(i=0;i<400;i++){
		if(board[i]==0){
			m=i%20;
			n=i/20;
			if(evaluesingle(m,n,2)>=4320){
				point[j++]=m;
				point[j++]=n;
			}}}
	for(i=0;i<j;i+=2){
		V=evaluesingle(point[i],point[i+1],2)+evaluesingle(point[i],point[i+1],1);
		if(max<V){
			max=V;
			my.x=point[i];
			my.y=point[i+1];
		}}
	if(j>0){
		my.flag=1;
	    return 1;
	}
	for(i=0;i<400;i++){                    //�ҽ��� 
		if(board[i]==0){
			m=i%20;
			n=i/20;
			if(evaluesingle(m, n, 1)>=4000){
				my.x=m;
				my.y=n;
				my.flag=1;
				return 1;
			}}}
	for(i=0;i<400;i++){                    //�ҽ��� 
		if(board[i]==0){
			m=i%20;
			n=i/20;
			if(evaluesingle(m, n, 2)>=4000){
				my.x=m;
				my.y=n;
				my.flag=1;
				return 1;
			}}}
	for(i=0;i<400;i++){                    //�ҽ��� 
		if(board[i]==0){
			m=i%20;
			n=i/20;
			if(evaluesingle(m, n, 1)>=3000){
				my.x=m;
				my.y=n;
				my.flag=1;
				return 1;
			}}}
	for(i=0;i<400;i++){                    //�ҽ��� 
		if(board[i]==0){
			m=i%20;
			n=i/20;
			if(evaluesingle(m, n, 2)>=3000){
				my.x=m;
				my.y=n;
				my.flag=1;
				return 1;
			}}}
	return 0;
}
